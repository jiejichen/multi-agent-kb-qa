from __future__ import annotations

from typing import Any

from app.agents.base import Agent, AgentContext
from app.core.config import DEFAULT_QUALITY_THRESHOLD
from app.schemas import AgentRole


class SupervisorAgent(Agent):
    role = AgentRole.SUPERVISOR
    name = "协同质检 Agent"

    def run(self, context: AgentContext, input_data: dict[str, Any]) -> dict[str, Any]:
        memory = context.memory
        score = 100
        issues: list[str] = []

        required = ["plan", "analysis", "content", "channel_strategy"]
        for key in required:
            if key not in memory:
                score -= 20
                issues.append(f"缺少 {key} 输出")

        if context.campaign.budget <= 0:
            score -= 5
            issues.append("预算为 0，渠道执行只能生成策略，无法估算投放规模")

        if len(context.campaign.channels) == 0:
            score -= 20
            issues.append("未指定触达渠道")

        decision = "approved" if score >= DEFAULT_QUALITY_THRESHOLD else "needs_revision"
        report = {
            "quality_score": max(score, 0),
            "decision": decision,
            "issues": issues,
            "final_recommendation": self._recommendation(decision, issues),
            "handoff": {
                "owner": "运营负责人",
                "next_actions": [
                    "确认活动权益和落地页链接",
                    "导入目标人群名单",
                    "配置渠道发送任务",
                    "上线后每日回收指标并复盘",
                ],
            },
        }
        context.memory["supervisor_report"] = report
        context.add_message(self.role, "已完成协作质检和最终汇总。", report)
        return report

    @staticmethod
    def _recommendation(decision: str, issues: list[str]) -> str:
        if decision == "approved":
            return "计划完整度较高，可以进入人工审批和执行配置。"
        return "建议先补齐关键缺口后再进入执行：" + "；".join(issues)
