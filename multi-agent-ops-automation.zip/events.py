from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any
from uuid import uuid4


@dataclass(slots=True)
class Event:
    type: str
    payload: dict[str, Any]
    id: str = field(default_factory=lambda: str(uuid4()))
    created_at: datetime = field(default_factory=datetime.utcnow)


class EventBus:
    def __init__(self) -> None:
        self._events: list[Event] = []

    def publish(self, event_type: str, payload: dict[str, Any]) -> Event:
        event = Event(type=event_type, payload=payload)
        self._events.append(event)
        return event

    def list_events(self) -> list[Event]:
        return list(self._events)
