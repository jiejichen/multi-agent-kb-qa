from __future__ import annotations

from collections import deque
from collections.abc import Iterator

from app.schemas import Task


class InMemoryTaskQueue:
    def __init__(self) -> None:
        self._items: deque[Task] = deque()

    def push(self, task: Task) -> None:
        self._items.append(task)

    def pop(self) -> Task | None:
        if not self._items:
            return None
        return self._items.popleft()

    def __iter__(self) -> Iterator[Task]:
        return iter(self._items)

    def __len__(self) -> int:
        return len(self._items)
