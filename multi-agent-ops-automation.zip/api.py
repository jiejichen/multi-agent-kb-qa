from __future__ import annotations

from fastapi import FastAPI, HTTPException

from app.core.workflow import OperationsWorkflow
from app.schemas import CampaignRequest, RunSummary, WorkflowRun
from app.storage import SQLiteStore

app = FastAPI(title="多 Agent 协同运营自动化系统", version="1.0.0")
store = SQLiteStore()
workflow = OperationsWorkflow(store=store)


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.post("/campaigns/run", response_model=WorkflowRun)
def run_campaign(campaign: CampaignRequest) -> WorkflowRun:
    return workflow.run_campaign(campaign)


@app.get("/runs", response_model=list[RunSummary])
def list_runs() -> list[RunSummary]:
    return store.list_runs()


@app.get("/runs/{run_id}", response_model=WorkflowRun)
def get_run(run_id: str) -> WorkflowRun:
    run = store.get_run(run_id)
    if run is None:
        raise HTTPException(status_code=404, detail="Run not found")
    return run
