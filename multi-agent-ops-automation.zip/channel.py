from __future__ import annotations

from typing import Any

from app.agents.base import Agent, AgentContext
from app.schemas import AgentRole


class ChannelAgent(Agent):
    role = AgentRole.CHANNEL
    name = "渠道运营 Agent"

    def run(self, context: AgentContext, input_data: dict[str, Any]) -> dict[str, Any]:
        campaign = context.campaign
        allocation = self._allocate_budget(campaign.channels, campaign.budget)
        schedule = [
            {
                "channel": channel,
                "send_window": self._send_window(channel),
                "frequency": "每 3 天最多 1 次" if channel.lower() in {"sms", "push"} else "每周 1-2 次",
                "budget": allocation.get(channel, 0),
            }
            for channel in campaign.channels
        ]
        strategy = {
            "schedule": schedule,
            "suppression_rules": [
                "已转化用户不再进入后续促销触达",
                "7 天内投诉或退订用户自动排除",
                "同一用户每天最多被 1 个付费渠道触达",
            ],
        }
        context.memory["channel_strategy"] = strategy
        context.add_message(self.role, "已完成渠道节奏和预算分配。", strategy)
        return strategy

    @staticmethod
    def _allocate_budget(channels: list[str], budget: float) -> dict[str, float]:
        if not channels or budget <= 0:
            return {channel: 0 for channel in channels}
        base = round(budget / len(channels), 2)
        return {channel: base for channel in channels}

    @staticmethod
    def _send_window(channel: str) -> str:
        mapping = {
            "email": "工作日 10:00-11:30",
            "sms": "工作日 14:00-17:00",
            "wechat": "工作日 18:00-20:00",
            "push": "工作日 12:00 或 20:00",
        }
        return mapping.get(channel.lower(), "工作日 10:00-18:00")
