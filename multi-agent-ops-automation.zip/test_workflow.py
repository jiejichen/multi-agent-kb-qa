from app.core.workflow import OperationsWorkflow
from app.schemas import CampaignRequest, TaskStatus
from app.storage.sqlite_store import SQLiteStore


def test_workflow_completes(tmp_path):
    store = SQLiteStore(tmp_path / "test.sqlite3")
    workflow = OperationsWorkflow(store=store)
    run = workflow.run_campaign(
        CampaignRequest(
            name="测试活动",
            goal="提升试用用户转化",
            audience="近 7 天注册未付费用户",
            channels=["email", "wechat"],
            budget=1000,
        )
    )

    assert run.status == TaskStatus.COMPLETED
    assert len(run.tasks) == 5
    assert run.result["supervisor_report"]["decision"] == "approved"
    assert store.get_run(run.id) is not None
