from __future__ import annotations

import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any
from urllib.parse import urlparse

from pydantic import ValidationError

from app.core.workflow import OperationsWorkflow
from app.schemas import CampaignRequest
from app.storage import SQLiteStore


store = SQLiteStore()
workflow = OperationsWorkflow(store=store)


class SimpleApiHandler(BaseHTTPRequestHandler):
    server_version = "OpsAutomationHTTP/1.0"

    def do_GET(self) -> None:
        path = urlparse(self.path).path
        if path == "/health":
            self._json(200, {"status": "ok"})
            return
        if path == "/runs":
            self._json(200, [row.model_dump(mode="json") for row in store.list_runs()])
            return
        if path.startswith("/runs/"):
            run_id = path.removeprefix("/runs/")
            run = store.get_run(run_id)
            if run is None:
                self._json(404, {"detail": "Run not found"})
                return
            self._json(200, run.model_dump(mode="json"))
            return
        self._json(404, {"detail": "Not found"})

    def do_POST(self) -> None:
        path = urlparse(self.path).path
        if path != "/campaigns/run":
            self._json(404, {"detail": "Not found"})
            return
        try:
            body = self._read_json()
            campaign = CampaignRequest.model_validate(body)
            run = workflow.run_campaign(campaign)
        except json.JSONDecodeError:
            self._json(400, {"detail": "Invalid JSON"})
            return
        except ValidationError as exc:
            self._json(422, {"detail": exc.errors()})
            return
        self._json(200, run.model_dump(mode="json"))

    def log_message(self, format: str, *args: Any) -> None:
        return

    def _read_json(self) -> dict[str, Any]:
        length = int(self.headers.get("Content-Length", "0"))
        raw = self.rfile.read(length)
        return json.loads(raw.decode("utf-8"))

    def _json(self, status: int, payload: Any) -> None:
        data = json.dumps(payload, ensure_ascii=False, indent=2).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)


def main(host: str = "127.0.0.1", port: int = 8000) -> None:
    server = ThreadingHTTPServer((host, port), SimpleApiHandler)
    print(f"服务已启动：http://{host}:{port}")
    print("可用接口：GET /health, GET /runs, GET /runs/{id}, POST /campaigns/run")
    server.serve_forever()


if __name__ == "__main__":
    main()
