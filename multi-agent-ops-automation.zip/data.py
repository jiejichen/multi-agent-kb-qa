from __future__ import annotations

from typing import Any

from app.agents.base import Agent, AgentContext
from app.schemas import AgentRole


class DataAgent(Agent):
    role = AgentRole.DATA
    name = "数据分析 Agent"

    def run(self, context: AgentContext, input_data: dict[str, Any]) -> dict[str, Any]:
        campaign = context.campaign
        channel_count = max(len(campaign.channels), 1)
        budget_per_channel = round(campaign.budget / channel_count, 2) if campaign.budget else 0
        analysis = {
            "target_segments": [
                {"name": campaign.audience, "priority": "high", "reason": "与本次目标直接匹配"},
                {"name": "近 90 天有互动用户", "priority": "medium", "reason": "响应概率较高"},
            ],
            "budget_per_channel": budget_per_channel,
            "recommended_kpis": {
                "open_rate": ">= 18%",
                "click_rate": ">= 3%",
                "conversion_rate": ">= 1.5%",
            },
            "risks": [
                "频次过高可能引发退订或投诉",
                "渠道归因需要统一口径",
            ],
        }
        context.memory["analysis"] = analysis
        context.add_message(self.role, "已完成目标人群、预算和指标建议。", analysis)
        return analysis
