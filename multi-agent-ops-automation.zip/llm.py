from __future__ import annotations

from typing import Protocol


class LLMClient(Protocol):
    def complete(self, prompt: str) -> str:
        raise NotImplementedError


class MockLLMClient:
    def complete(self, prompt: str) -> str:
        first_line = prompt.strip().splitlines()[0] if prompt.strip() else "运营任务"
        return f"基于规则引擎生成：{first_line}"
