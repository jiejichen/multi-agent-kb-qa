from __future__ import annotations

from app.agents.base import Agent
from app.agents.channel import ChannelAgent
from app.agents.content import ContentAgent
from app.agents.data import DataAgent
from app.agents.planner import PlannerAgent
from app.agents.supervisor import SupervisorAgent
from app.schemas import AgentRole


class AgentRegistry:
    def __init__(self) -> None:
        self._agents: dict[AgentRole, Agent] = {}

    def register(self, agent: Agent) -> None:
        self._agents[agent.role] = agent

    def get(self, role: AgentRole) -> Agent:
        if role not in self._agents:
            raise KeyError(f"Agent role is not registered: {role}")
        return self._agents[role]

    def roles(self) -> list[AgentRole]:
        return list(self._agents.keys())


def build_default_registry() -> AgentRegistry:
    registry = AgentRegistry()
    registry.register(PlannerAgent())
    registry.register(DataAgent())
    registry.register(ContentAgent())
    registry.register(ChannelAgent())
    registry.register(SupervisorAgent())
    return registry
