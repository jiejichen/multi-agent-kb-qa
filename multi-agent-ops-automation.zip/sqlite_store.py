from __future__ import annotations

import json
import sqlite3
from datetime import datetime
from pathlib import Path

from app.core.config import DB_PATH
from app.schemas import RunSummary, WorkflowRun


class SQLiteStore:
    def __init__(self, db_path: Path | str = DB_PATH) -> None:
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS workflow_runs (
                    id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    goal TEXT NOT NULL,
                    status TEXT NOT NULL,
                    payload TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
                """
            )

    def save_run(self, run: WorkflowRun) -> None:
        payload = run.model_dump_json()
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO workflow_runs (id, name, goal, status, payload, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(id) DO UPDATE SET
                    name = excluded.name,
                    goal = excluded.goal,
                    status = excluded.status,
                    payload = excluded.payload,
                    updated_at = excluded.updated_at
                """,
                (
                    run.id,
                    run.campaign.name,
                    run.campaign.goal,
                    run.status.value,
                    payload,
                    run.created_at.isoformat(),
                    run.updated_at.isoformat(),
                ),
            )

    def get_run(self, run_id: str) -> WorkflowRun | None:
        with self._connect() as conn:
            row = conn.execute("SELECT payload FROM workflow_runs WHERE id = ?", (run_id,)).fetchone()
        if row is None:
            return None
        return WorkflowRun.model_validate(json.loads(row["payload"]))

    def list_runs(self) -> list[RunSummary]:
        with self._connect() as conn:
            rows = conn.execute(
                """
                SELECT id, name, goal, status, created_at, updated_at
                FROM workflow_runs
                ORDER BY updated_at DESC
                """
            ).fetchall()
        return [
            RunSummary(
                id=row["id"],
                name=row["name"],
                goal=row["goal"],
                status=row["status"],
                created_at=datetime.fromisoformat(row["created_at"]),
                updated_at=datetime.fromisoformat(row["updated_at"]),
            )
            for row in rows
        ]
