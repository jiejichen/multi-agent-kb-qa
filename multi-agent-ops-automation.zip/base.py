from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any

from app.agents.llm import LLMClient, MockLLMClient
from app.schemas import AgentMessage, AgentRole, CampaignRequest


@dataclass(slots=True)
class AgentContext:
    campaign: CampaignRequest
    memory: dict[str, Any]
    messages: list[AgentMessage]

    def add_message(self, role: AgentRole, content: str, data: dict[str, Any] | None = None) -> AgentMessage:
        message = AgentMessage(role=role, content=content, data=data or {})
        self.messages.append(message)
        return message


class Agent(ABC):
    role: AgentRole
    name: str

    def __init__(self, llm: LLMClient | None = None) -> None:
        self.llm = llm or MockLLMClient()

    @abstractmethod
    def run(self, context: AgentContext, input_data: dict[str, Any]) -> dict[str, Any]:
        raise NotImplementedError
