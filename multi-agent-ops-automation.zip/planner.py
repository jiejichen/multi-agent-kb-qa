from __future__ import annotations

from typing import Any

from app.agents.base import Agent, AgentContext
from app.schemas import AgentRole


class PlannerAgent(Agent):
    role = AgentRole.PLANNER
    name = "运营策略规划 Agent"

    def run(self, context: AgentContext, input_data: dict[str, Any]) -> dict[str, Any]:
        campaign = context.campaign
        stages = [
            {"stage": "洞察", "owner": "data", "objective": "识别目标人群和关键机会"},
            {"stage": "内容", "owner": "content", "objective": "生成适配渠道的触达内容"},
            {"stage": "投放", "owner": "channel", "objective": "安排渠道节奏、预算和频次"},
            {"stage": "复盘", "owner": "supervisor", "objective": "检查质量、风险和下一步动作"},
        ]
        kpis = [
            "触达人数",
            "打开率",
            "点击率",
            "转化率",
            "单次转化成本",
        ]
        plan = {
            "campaign_name": campaign.name,
            "goal": campaign.goal,
            "audience": campaign.audience,
            "stages": stages,
            "kpis": kpis,
            "constraints": campaign.constraints,
        }
        context.memory["plan"] = plan
        context.add_message(self.role, "已完成运营目标拆解和协作计划。", plan)
        return plan
