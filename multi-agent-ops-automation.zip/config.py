from __future__ import annotations

from pathlib import Path

BASE_DIR = Path(__file__).resolve().parents[2]
DATA_DIR = BASE_DIR / "data"
DB_PATH = DATA_DIR / "ops_automation.sqlite3"

DEFAULT_QUALITY_THRESHOLD = 80
