from __future__ import annotations

import argparse
import json

from app.core.workflow import OperationsWorkflow
from app.schemas import CampaignRequest
from app.storage import SQLiteStore


def _workflow() -> OperationsWorkflow:
    return OperationsWorkflow(store=SQLiteStore())


def run_demo(_: argparse.Namespace) -> None:
    campaign = CampaignRequest(
        name="会员召回自动化活动",
        goal="召回 30 天未活跃会员并推动复购",
        audience="30 天未登录且历史消费大于 200 元的会员",
        channels=["email", "sms", "wechat"],
        budget=8000,
        constraints=["避免过度打扰", "所有内容需要保留退订路径"],
    )
    run = _workflow().run_campaign(campaign)
    print(run.model_dump_json(indent=2))


def create_campaign(args: argparse.Namespace) -> None:
    campaign = CampaignRequest(
        name=args.name,
        goal=args.goal,
        audience=args.audience,
        channels=[item.strip() for item in args.channels.split(",") if item.strip()],
        budget=args.budget,
    )
    run = _workflow().run_campaign(campaign)
    print(f"已完成运行：{run.id}")
    print(json.dumps(run.result, ensure_ascii=False, indent=2))


def list_runs(_: argparse.Namespace) -> None:
    rows = SQLiteStore().list_runs()
    if not rows:
        print("暂无运行记录")
        return
    for row in rows:
        print(f"{row.id}\t{row.status.value}\t{row.name}\t{row.updated_at.isoformat(timespec='seconds')}")


def show_run(args: argparse.Namespace) -> None:
    run = SQLiteStore().get_run(args.run_id)
    if run is None:
        raise SystemExit("未找到运行记录")
    print(run.model_dump_json(indent=2))


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="多 Agent 协同运营自动化系统")
    subparsers = parser.add_subparsers(dest="command", required=True)

    demo = subparsers.add_parser("run-demo", help="运行内置示例")
    demo.set_defaults(func=run_demo)

    create = subparsers.add_parser("create-campaign", help="创建并执行活动")
    create.add_argument("--name", required=True, help="活动名称")
    create.add_argument("--goal", required=True, help="运营目标")
    create.add_argument("--audience", default="目标用户", help="目标人群")
    create.add_argument("--channels", default="email,wechat", help="逗号分隔的渠道")
    create.add_argument("--budget", type=float, default=0, help="预算")
    create.set_defaults(func=create_campaign)

    runs = subparsers.add_parser("list-runs", help="查看运行记录")
    runs.set_defaults(func=list_runs)

    show = subparsers.add_parser("show-run", help="查看单次运行详情")
    show.add_argument("run_id")
    show.set_defaults(func=show_run)
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
