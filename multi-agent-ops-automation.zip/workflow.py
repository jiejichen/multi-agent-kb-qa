from __future__ import annotations

from datetime import datetime
from typing import Any

from app.agents import AgentContext, AgentRegistry, build_default_registry
from app.core.events import EventBus
from app.core.queue import InMemoryTaskQueue
from app.schemas import AgentRole, CampaignRequest, Task, TaskStatus, WorkflowRun
from app.storage.sqlite_store import SQLiteStore


class OperationsWorkflow:
    def __init__(
        self,
        registry: AgentRegistry | None = None,
        store: SQLiteStore | None = None,
        event_bus: EventBus | None = None,
    ) -> None:
        self.registry = registry or build_default_registry()
        self.store = store or SQLiteStore()
        self.event_bus = event_bus or EventBus()

    def run_campaign(self, campaign: CampaignRequest) -> WorkflowRun:
        run = WorkflowRun(campaign=campaign, status=TaskStatus.RUNNING)
        context = AgentContext(campaign=campaign, memory={}, messages=run.messages)
        queue = self._build_queue(campaign)
        run.tasks = list(queue)
        self.store.save_run(run)
        self.event_bus.publish("workflow.started", {"run_id": run.id, "campaign": campaign.name})

        while len(queue):
            task = queue.pop()
            if task is None:
                break
            self._execute_task(task, context)
            run.updated_at = datetime.utcnow()
            self.store.save_run(run)

        run.status = TaskStatus.COMPLETED if all(task.status == TaskStatus.COMPLETED for task in run.tasks) else TaskStatus.FAILED
        run.messages = context.messages
        run.result = self._build_result(context)
        run.updated_at = datetime.utcnow()
        self.store.save_run(run)
        self.event_bus.publish("workflow.completed", {"run_id": run.id, "status": run.status})
        return run

    def _build_queue(self, campaign: CampaignRequest) -> InMemoryTaskQueue:
        queue = InMemoryTaskQueue()
        for name, role in [
            ("制定运营协作计划", AgentRole.PLANNER),
            ("分析人群与指标", AgentRole.DATA),
            ("生成多渠道内容", AgentRole.CONTENT),
            ("规划渠道投放", AgentRole.CHANNEL),
            ("质检与汇总", AgentRole.SUPERVISOR),
        ]:
            queue.push(Task(name=name, role=role, input_data=campaign.model_dump()))
        return queue

    def _execute_task(self, task: Task, context: AgentContext) -> None:
        task.status = TaskStatus.RUNNING
        task.updated_at = datetime.utcnow()
        self.event_bus.publish("task.started", {"task_id": task.id, "role": task.role})
        try:
            agent = self.registry.get(task.role)
            task.output_data = agent.run(context, task.input_data)
            task.status = TaskStatus.COMPLETED
            self.event_bus.publish("task.completed", {"task_id": task.id, "role": task.role})
        except Exception as exc:
            task.status = TaskStatus.FAILED
            task.error = str(exc)
            self.event_bus.publish("task.failed", {"task_id": task.id, "role": task.role, "error": str(exc)})
        finally:
            task.updated_at = datetime.utcnow()

    @staticmethod
    def _build_result(context: AgentContext) -> dict[str, Any]:
        return {
            "plan": context.memory.get("plan", {}),
            "analysis": context.memory.get("analysis", {}),
            "content": context.memory.get("content", {}),
            "channel_strategy": context.memory.get("channel_strategy", {}),
            "supervisor_report": context.memory.get("supervisor_report", {}),
        }
