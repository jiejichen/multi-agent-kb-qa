# 多 Agent 协同运营自动化系统

这是一个可本地运行的多 Agent 协同运营自动化系统，用于把运营目标拆解成可追踪、可审核、可自动执行的任务流。

系统内置 5 类 Agent：

- `PlannerAgent`：把运营目标拆成执行计划
- `ContentAgent`：生成内容草案
- `ChannelAgent`：规划渠道投放
- `DataAgent`：分析指标并给出建议
- `SupervisorAgent`：做质量检查和最终汇总

默认使用规则引擎模拟 Agent 决策，不依赖外部大模型。你可以在 `app/agents/llm.py` 中替换为 OpenAI、企业私有模型或其他推理服务。

## 快速开始

```powershell
python -m app.cli run-demo
```

启动零依赖 HTTP API：

```powershell
python -m app.simple_api
```

启动 FastAPI 版本：

```powershell
pip install -r requirements.txt
uvicorn app.api:app --reload --port 8000
```

访问：

- FastAPI 文档：http://127.0.0.1:8000/docs
- 健康检查：http://127.0.0.1:8000/health

## 常用命令

```powershell
python -m app.cli create-campaign --name "618 拉新活动" --goal "提升新用户注册并促进首单转化"
python -m app.cli list-runs
python -m app.cli show-run <run_id>
```

## API 示例

创建并执行一个运营任务：

```http
POST /campaigns/run
Content-Type: application/json

{
  "name": "会员召回活动",
  "goal": "召回 30 天未活跃会员，推动复购",
  "audience": "30 天未登录的老会员",
  "channels": ["email", "sms", "wechat"],
  "budget": 5000
}
```

## 项目结构

```text
app/
  agents/        Agent 定义和协作协议
  core/          工作流、队列、事件、配置
  storage/       SQLite 存储
  api.py         FastAPI 服务
  cli.py         命令行入口
  schemas.py     数据结构
tests/           基础测试
data/            本地 SQLite 数据库目录
```

## 后续扩展方向

- 把 `MockLLMClient` 替换成真实 LLM
- 接入 CRM、企微、飞书、邮件、短信、广告平台
- 增加人工审批节点
- 增加定时任务和指标回流
- 把 Agent 输出接入实际投放执行器
