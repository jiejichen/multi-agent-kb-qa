from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any
from uuid import uuid4

from pydantic import BaseModel, Field


class TaskStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


class AgentRole(str, Enum):
    PLANNER = "planner"
    CONTENT = "content"
    CHANNEL = "channel"
    DATA = "data"
    SUPERVISOR = "supervisor"


class CampaignRequest(BaseModel):
    name: str = Field(..., min_length=1)
    goal: str = Field(..., min_length=1)
    audience: str = "目标用户"
    channels: list[str] = Field(default_factory=lambda: ["email", "wechat"])
    budget: float = 0
    constraints: list[str] = Field(default_factory=list)


class AgentMessage(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid4()))
    role: AgentRole
    content: str
    data: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=datetime.utcnow)


class Task(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid4()))
    name: str
    role: AgentRole
    input_data: dict[str, Any] = Field(default_factory=dict)
    status: TaskStatus = TaskStatus.PENDING
    output_data: dict[str, Any] = Field(default_factory=dict)
    error: str | None = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


class WorkflowRun(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid4()))
    campaign: CampaignRequest
    status: TaskStatus = TaskStatus.PENDING
    tasks: list[Task] = Field(default_factory=list)
    messages: list[AgentMessage] = Field(default_factory=list)
    result: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


class RunSummary(BaseModel):
    id: str
    name: str
    goal: str
    status: TaskStatus
    created_at: datetime
    updated_at: datetime
