from __future__ import annotations

from typing import Any

from app.agents.base import Agent, AgentContext
from app.schemas import AgentRole


class ContentAgent(Agent):
    role = AgentRole.CONTENT
    name = "内容生成 Agent"

    def run(self, context: AgentContext, input_data: dict[str, Any]) -> dict[str, Any]:
        campaign = context.campaign
        content_pack = {
            "core_message": f"{campaign.audience}专属：{campaign.goal}",
            "variants": [
                {
                    "channel": channel,
                    "title": self._title_for(channel, campaign.name),
                    "body": self._body_for(channel, campaign.goal),
                    "cta": "立即查看",
                }
                for channel in campaign.channels
            ],
            "tone": "清晰、可信、有行动指向",
        }
        context.memory["content"] = content_pack
        context.add_message(self.role, "已生成多渠道内容草案。", content_pack)
        return content_pack

    @staticmethod
    def _title_for(channel: str, name: str) -> str:
        mapping = {
            "email": f"{name}：给你的专属方案",
            "sms": f"{name}限时提醒",
            "wechat": f"{name}正在进行",
            "push": f"{name}新消息",
        }
        return mapping.get(channel.lower(), f"{name}活动通知")

    @staticmethod
    def _body_for(channel: str, goal: str) -> str:
        if channel.lower() == "sms":
            return f"{goal}。点击链接了解详情，退订回 T。"
        return f"我们为你准备了本次活动方案，核心目标是：{goal}。现在参与，可获得更顺畅的体验和更明确的权益。"
